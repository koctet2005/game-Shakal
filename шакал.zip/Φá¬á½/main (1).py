import os
import pygame
import island_generation, draw_functions , nomerkey, tile_functions


'''
СТРОЕНИЕ ТАЙЛА ПОЛЯ В МАССИВЕ

0 - Имя текущей картинки, то, что будет отрисовываться при рендеринге, изначально Blank - пустая клетка
1 - Имя картинки, которая расположена на обороте. Так, при первом приходе на клетку, элементу 0 присваевается элемент 1.
2 - Количество пиратов
3 - Их владелец, w - white, b - black, r - red, y - yellow
4 - Количество золота




'''
def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    image = pygame.image.load(fullname).convert()
    return image


def draw_pirate(color, left, top, cell_size, i, j, number):
    global screen
    draw = draw_functions.pirate_draw((left + cell_size * i + cell_size // 2, top + cell_size * j + cell_size // 2), number, pygame.Color(color), screen)
    draw[0]
    screen.blit(draw[1], (left + cell_size * i + cell_size // 2 - 5, top + cell_size * j + cell_size // 2 - 10))


chosen = None





class Board:
    # создание поля
    def __init__(self, width, height):
        self.width = width
        self.height = height
        island = island_generation.generation()
        self.board = [[['start', 'тут будет название тйла, которым он станет при исследовании', 0, '-', 0] for i in range(width)]for _ in range(height)]
        number = 0
        for i in range(height):
            for j in range(width):
                if (i == 0 and j == 0) or (i == 0 and j == 10) or (i == 10 and j == 0) or (i == 10 and j == 10):
                    self.board[i][j] = 'empty'
                else:
                    self.board[i][j][1] = island[number]
                    number += 1
        # значения по умолчанию
        self.left = 7
        self.top = 7
        self.cell_size = 75

    # настройка внешнего вида
    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size
    
    def move_possible(a, b): #это функция проверяет, возможен ли ход
        #пока только проверка расстояния без всяких там крепостей
        return True
    
    def render(self):
        global images
        for i in range(self.width):
            for j in range(self.height):
                if self.board[i][j] != 'empty':
                    screen.blit(load_image(self.board[i][j][0] + '.png'), (self.left + self.cell_size * i, self.top + self.cell_size * j))
                    pygame.draw.rect(screen, pygame.Color('white'), pygame.Rect(self.left + self.cell_size * i, self.top + self.cell_size * j, self.cell_size, self.cell_size), 2)
                    #отрисовка пиратов
                    if self.board[i][j][3] == 'w':
                        draw_pirate('white', self.left, self.top, self.cell_size, i, j, self.board[i][j][2])
                    elif self.board[i][j][3] == 'b':
                        draw_pirate('black', self.left, self.top, self.cell_size, i, j, self.board[i][j][2])
                    elif self.board[i][j][3] == 'y':
                        draw_pirate('yellow', self.left, self.top, self.cell_size, i, j, self.board[i][j][2])
                    elif self.board[i][j][3] == 'r':
                        draw_pirate('red', self.left, self.top, self.cell_size, i, j, self.board[i][j][2])
                    if self.board[i][j][4] != 0:
                        draw = draw_functions.gold_draw((self.left + self.cell_size * i + self.cell_size - 11, self.top + self.cell_size * j + 11), self.board[i][j][4], screen)
                        draw[0]
                        screen.blit(draw[1], (self.left + self.cell_size * i + self.cell_size - 15, self.top + self.cell_size * j))
                        


    
    def get_click(self, mouse_pos):
        cell = self.get_cell(mouse_pos)
        self.on_click(cell)

    def get_cell(self, mouse_pos):
        x = mouse_pos[0]
        y = mouse_pos[1]
        if y > self.height * self.cell_size + self.top or y < self.top or x < self.left or x > self.left + self.width * self.cell_size:
            return None
        else:
            return ((x - self.left) // self.cell_size, (y - self.top) // self.cell_size)
        
    def on_click(self, cell_coords):
        global chosen
        #поясняю написанную тут хрень: в первом элементе списка, соответствующего клетке поля содержится то, что мы сейчас видим(изначально везде неизведанные), вторая - то, что там на самом деле, далее элементы с содержанием пиратов каждого игрока
        if cell_coords != None:
            if self.board[cell_coords[0]][cell_coords[1]] != 'empty':
                if self.board[cell_coords[0]][cell_coords[1]][2] > 0: 
                    chosen = (*cell_coords, False)
'''
в переменную chosen записываем ее координаты.
            
так все время либо есть выбранная клетка с которой будем ходить, и далее любое нажатие либо ее перевыберет либо совершит ход,
ибо ее выбираем
                          
в каждой клетке есть 3 позиции под пирата (потом пропишем формулы их координат). Условно квадрат два на два, три его позиции займут пираты, в четвертой указаны монеты - нарисована монетка и их количество. И да, размер поля надо увеличить.

'''

ships = {'w': 0, 'b': 0, 'r': 0, 'y': 0}   #люди на кораблях. У тайлов кораблей и моря несколько иная структура, хочу чтобы они были не в списке board.board


pygame.init()
size = width, height = 839, 839
screen = pygame.display.set_mode(size)



def move_pirate_people(startX, startY, endX, endY):
        global board, chosen
        if board.board[startX][startY][2] != 0:
            board.board[startX][startY][2] -= 1
            n = board.board[startX][startY][3]
            if board.board[startX][startY][2] == 0:
                board.board[startX][startY][3] = '-' # локация становится ничьей
            if board.board[endX][endY][3] != n and board.board[endX][endY][3] != '-':
                ships[board.board[endX][endY][3]] += board.board[endX][endY][2]
                board.board[endX][endY][2] = 0
            board.board[endX][endY][2] += 1
            board.board[endX][endY][3] = n
            if board.board[endX][endY] != 'empty':
                if board.board[endX][endY][0] == 'start':
                    board.board[endX][endY][0] = board.board[endX][endY][1]
            if board.board[endX][endY][1] != 'empty_cage':
                    move_pirate_tile(startX, startY, endX, endY, n)
            if chosen[2] and board.board[startX][startY][4] > 0:
                board.board[startX][startY][4] -= 1
                board.board[endX][endY][4] += 1
            chosen = None
            
            
sp_move_pirate = 0
ozero = (0,0)
nomer = 0
def move_pirate_tile(startX, startY, endX, endY, color):
    revive_pirates()
    screen.fill((0, 0, 0))
    board.render()
    pygame.display.flip()# j,yjdkz. 'rhfy
    nomer = nomerkey.nomer()
    sp_move_pirate = tile_functions.raspredelitelkletok(endX, endY, board.board, nomer, color, startX, startY, ozero)
    
    move_pirate_people(endX, endY, sp_move_pirate[0], sp_move_pirate[1])



def revive_pirates():
    board.board[0][5][2] += ships['b']
    board.board[0][5][3] = 'b'
    ships['b'] = 0
    board.board[5][0][2] += ships['w']
    board.board[5][0][3] = 'w'
    ships['w'] = 0
    board.board[10][5][2] += ships['r']
    board.board[10][5][3] = 'r'
    ships['r'] = 0
    board.board[5][10][2] += ships['y']
    board.board[5][10][3] = 'y'
    ships['y'] = 0




board = Board(11, 11)
running = True
'''    
K_KP1                 keypad 1
K_KP2                 keypad 2
K_KP3                 keypad 3
K_KP4                 keypad 4
K_KP5                 keypad 5
K_KP6                 keypad 6
K_KP7                 keypad 7
K_KP8                 keypad 8
K_KP9                 keypad 9
в зависимости от нажатия кнопки кипада пират движется влево, вправо и тд
этот коммент мне понадобится еще, не удаляйте
'''
board.board[0][5][2] = 3
board.board[0][5][3] = 'b'
board.board[0][5][1] = 'fort'
board.board[0][5][0] = board.board[0][5][1]

board.board[5][0][2] = 3
board.board[5][0][3] = 'w'
board.board[5][0][1] = 'fort'
board.board[5][0][0] = board.board[5][0][1]

board.board[10][5][2] = 3
board.board[10][5][3] = 'r'
board.board[10][5][1] = 'fort'
board.board[10][5][0] = board.board[10][5][1]

board.board[5][10][2] = 3
board.board[5][10][3] = 'y'
board.board[5][10][1] = 'fort'
board.board[5][10][0] = board.board[5][10][1]
while running:
    pressed_keys = pygame.key.get_pressed()
    if pressed_keys[pygame.K_KP8]:
        if chosen != None:
            move_pirate_people(chosen[0], chosen[1], chosen[0], chosen[1] - 1)
        
    if pressed_keys[pygame.K_KP2]:
        if chosen != None:
            move_pirate_people(chosen[0], chosen[1], chosen[0], chosen[1] + 1)

    if pressed_keys[pygame.K_KP6]:
        if chosen != None:
            move_pirate_people(chosen[0], chosen[1], chosen[0] + 1, chosen[1])

    if pressed_keys[pygame.K_KP4]:
        if chosen != None:
            move_pirate_people(chosen[0], chosen[1], chosen[0] - 1, chosen[1])
    
    if pressed_keys[pygame.K_KP9]:
        if chosen != None:
            move_pirate_people(chosen[0], chosen[1], chosen[0] + 1, chosen[1] - 1)
    
    if pressed_keys[pygame.K_KP7]:
        if chosen != None:
            move_pirate_people(chosen[0], chosen[1], chosen[0] - 1, chosen[1] - 1)
            
    if pressed_keys[pygame.K_KP3]:
        if chosen != None:
            move_pirate_people(chosen[0], chosen[1], chosen[0] + 1, chosen[1] + 1)
    
    if pressed_keys[pygame.K_KP1]:
        if chosen != None:
            move_pirate_people(chosen[0], chosen[1], chosen[0] - 1, chosen[1] + 1)
    

    if pressed_keys[pygame.K_KP5]:
        if chosen != None:
            if chosen[2]:
                board.board[chosen[0]][chosen[1]][5] = False
            else:
                board.board[chosen[0]][chosen[1]][5] = True
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            board.get_click(event.pos)
    
    revive_pirates()
    
    screen.fill((0, 0, 0))
    board.render()
    pygame.display.flip()

pygame.quit()