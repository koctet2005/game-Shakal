#  делаю список где будет лежать карточки и замешиваю 
import random


def generation():
    spmap = []
    #spmap.append('airplane')
    for i in range(5):
        spmap.append('arrow-3')
        spmap.append('arrow-4')
        spmap.append('arrow-41221')
        spmap.append('arrowleftright')
        spmap.append('arrowright')
        spmap.append('arrowupright')
        #spmap.append('pitfall')
        #spmap.append('coins3')
        spmap.append('arrowdiog')
    for i in range(4):
        spmap.append('horse')
        #spmap.append('rotate-4')
        #spmap.append('fort')
    #spmap.append('coins4')
    #spmap.append('coins4')
        #spmap.append('balloon')
        #spmap.append('gun')
    #for i in range(4):
        #spmap.append('rom')
        #spmap.append('rotate-3')
       # spmap.append('crocodile')
    #for i in range(5):
        #spmap.append('rotate-2')
        #spmap.append('coins1')
        #spmap.append('coins2')
   # for i in range(6):
        #spmap.append('ice')
   # spmap.append('cannibal')
    #spmap.append('coins5')
    for i in range(78):
        spmap.append('empty_cage')
  #  spmap.append('fort-w-aborigine')
   # spmap.append('rotate-5')
    random.shuffle(spmap)
    return spmap
