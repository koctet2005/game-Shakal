import pygame
from math import pi
def nomer():
    
    while True:
        pressed_keys = pygame.key.get_pressed()
        for event in pygame.event.get():
            if pressed_keys[pygame.K_KP9]:
                return 9
            if pressed_keys[pygame.K_KP8]:
                return 8
                
            if pressed_keys[pygame.K_KP7]:
                return 7
                
            if pressed_keys[pygame.K_KP6]:
                return 6
                
            if pressed_keys[pygame.K_KP5]:
                return 5
                
            if pressed_keys[pygame.K_KP4]:
                return 4
                
            if pressed_keys[pygame.K_KP3]:
                return 3
                
            if pressed_keys[pygame.K_KP2]:
                return 2
                
            if pressed_keys[pygame.K_KP1]:
                return 1
