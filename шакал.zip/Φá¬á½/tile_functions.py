import pygame
import time
import nomerkey
ozero = (0, 0)

def raspredelitelkletok(endX, endY, board, k, color, startX, startY, ozero):
    print(board[endX][endY][0])
    k = nomerkey.nomer()
    if board[endX][endY][0] == 'arrow-4':
        x = arrow4(endX, endY, k)
        return  x
    elif board[endX][endY][0] == 'arrow-3':
        x = arrow3(endX, endY, k)
        return x
    elif board[endX][endY][0] == 'arrow-41221':
        x = arrow41221(endX, endY, k)
        return x
    elif board[endX][endY][0] == 'arrowdiog':
        x = arrowdiog(endX, endY, k)
        return x
    elif board[endX][endY][0] == 'arrowleftright':
        x = arrowleftright(endX, endY, k)
        return x
    elif board[endX][endY][0] == 'arrowright':
        x = arrowright(endX, endY, k)
        return x
    elif board[endX][endY][0] == 'arrowupright':
        x = arrowupright(endX, endY, k)
        return x
    elif board[endX][endY][0] == 'horse':
        x = horse(endX, endY, k)
        return x


def arrowright(endX, endY, k):
    ozero = (1, 0)
    return (endX + 1, endY, ozero)

def arrowupright(endX, endY, k):
    ozero = (-1, 1)
    return (endX + 1, endY - 1, ozero)



def arrowleftright(endX, endY, k):
    if k == 4:
       x = KP4(endX, endY)
       return x
    elif k == 6:
        x = KP6(endX, endY)
        return x
    else:
        k = nomerkey.nomer()
        return arrowleftright(endX, endY, k)
        
    

def  arrowdiog(endX, endY, k):
    if k == 9:
        x = KP9(endX, endY)
        return x
    elif k == 1:
        x = KP1(endX, endY)
        return x
    else:
        k = nomerkey.nomer()
        return arrowdiog(endX, endY, k)
    

def arrow41221(endX, endY, k):
    if k == 2:
        x = KP2(endX, endY)
        return x
    elif k == 4:
        x = KP4(endX, endY)
        return x
    elif k == 6:
        x = KP6(endX, endY)
        return x
    elif k == 8:
        x = KP8(endX, endY)
        return x
    else:
        k = nomerkey.nomer()
        return arrow41221(endX, endY, k)
    
    
def arrow4(endX, endY, k):
    if k == 1:
        x = KP1(endX, endY)
        return x
    elif k == 3:
        x = KP3(endX, endY)
        return x
    elif k == 7:
        x = KP7(endX, endY)
        return x
    elif k == 9:
        x = KP9(endX, endY)
        return x
    else:
        k = nomerkey.nomer()
        return arrow4(endX, endY, k)
    

def arrow3(endX, endY, k):
    if k == 6:
        x = KP6(endX, endY)
        return x
    elif k == 7:
        x = KP7(endX, endY)
        return x
    elif k == 2:
        x = KP2(endX, endY)
        return x
    else:
        k = nomerkey.nomer()
        return arrow3(endX, endY, k)
    
def horse(endX, endY, k):
    print(k)
    if k == 1:
        ozero = (-1, -2)
        return (endX - 1, endY - 2)
    elif k == 2:
        ozero = (-2, -1)
        return (endX - 2, endY - 1)
    elif k == 3:
        ozero = (-2, 1)
        return (endX - 2, endY + 1)
    elif k == 4:
        ozero = (-1, 2)
        return (endX - 1, endY + 2)
    elif k == 9:
        ozero = (1, 2)
        return (endX + 1, endY + 2)
    elif k == 6:
        ozero = (-1, -1)
        return (endX + 2, endY + 1)
    elif k == 7:
        ozero = (2, -1)
        return (endX + 2, endY - 1)
    elif k == 8:
        ozero = (1, -2)
        return (endX + 1, endY - 2)
    else:
        k = nomerkey.nomer()
        return horse(endX, endY, k)
        

def KP1(endX, endY):
    global ozero
    ozero = (-1, 1)
    return (endX - 1, endY + 1 , ozero)


def KP2(endX, endY):
    global ozero
    ozero = (0, 1)
    return (endX , endY + 1, ozero)


def KP3(endX, endY):
    global ozero
    ozero = (1, 1)
    return (endX + 1, endY + 1, ozero)


def KP4(endX, endY):
    global ozero
    ozero = (-1, 0)
    return (endX - 1, endY, ozero)


def KP6(endX, endY):
    global ozero
    ozero = (1, 0)
    return (endX + 1, endY , ozero)


def KP7(endX, endY):
    global ozero
    ozero = (-1, -1)
    return (endX - 1, endY - 1, ozero)


def KP8(endX, endY):
    global ozero
    ozero = (0, -1)
    return (endX , endY - 1, ozero)


def KP9(endX, endY):
    global ozero
    ozero = (1, -1)
    return (endX + 1, endY - 1, ozero)