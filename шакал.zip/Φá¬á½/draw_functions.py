import pygame


def pirate_draw(centre, number, color, screen):
    font = pygame.font.SysFont('arial', 20) #шрифт
    if color != (0, 0, 0, 255):
        number_draw = font.render(str(number), 1, (0, 0, 0))
    else:
        number_draw = font.render(str(number), 1, (255, 255, 255))
    return(pygame.draw.circle(screen, color, centre, 10, 0), number_draw)


def gold_draw(centre, number, screen):
    font = pygame.font.SysFont('arial', 20) #шрифт
    number_draw = font.render(str(number), 1, (0, 0, 0))
    return(pygame.draw.circle(screen, pygame.Color('yellow'), centre, 10, 0), number_draw)